# MyCaptcha service
Simple captcha API.