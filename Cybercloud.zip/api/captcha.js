import crypto from 'crypto';

export default function handler(req, res) {
  const token = crypto.randomBytes(20).toString("hex");
  res.json({ success: true, token });
}
