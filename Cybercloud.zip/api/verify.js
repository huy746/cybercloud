export default function handler(req, res) {
  const { token } = req.body;
  if (!token) return res.json({ success: false });
  res.json({ success: true });
}
