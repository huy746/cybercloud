import { redis } from "./db.js";
import crypto from "crypto";

export async function createToken(siteKey) {
  const token = crypto.randomBytes(32).toString("hex");
  await redis.set(`captcha:${token}`, JSON.stringify({
    siteKey,
    valid: true,
    time: Date.now()
  }), "EX", 120);
  return { token };
}