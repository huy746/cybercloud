import { redis } from "./db.js";

export async function verifyToken(secretKey, token) {
  const data = await redis.get(`captcha:${token}`);
  if (!data) return { success: false };
  const obj = JSON.parse(data);
  if (secretKey !== "YOUR_SECRET_KEY") return { success: false };
  await redis.del(`captcha:${token}`);
  return { success: true };
}