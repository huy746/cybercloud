import express from "express";
import bodyParser from "body-parser";
import { createToken } from "./token.js";
import { verifyToken } from "./verify.js";

const app = express();
app.use(bodyParser.json());
app.use(express.static("../public"));

app.post("/api/token", async (req, res) => {
  const { site_key } = req.body;
  return res.json(await createToken(site_key));
});

app.post("/api/verify", async (req, res) => {
  const { secret_key, token } = req.body;
  return res.json(await verifyToken(secret_key, token));
});

app.listen(4000, () => console.log("Captcha API running on 4000"));
