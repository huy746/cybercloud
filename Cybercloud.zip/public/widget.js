(async function() {
  const container = document.querySelector("[data-mycaptcha]");
  const sitekey = container.getAttribute("data-sitekey");

  const res = await fetch("/api/token", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ site_key: sitekey })
  });

  const data = await res.json();

  container.innerHTML = `
    <div class="captcha-box">
      <p>Tôi không phải robot</p>
      <button id="done">Xác nhận</button>
    </div>
  `;

  document.getElementById("done").onclick = () => {
    container.setAttribute("data-token", data.token);
    container.innerHTML = `<p>✔ Đã xác minh</p>`;
  };
})();
